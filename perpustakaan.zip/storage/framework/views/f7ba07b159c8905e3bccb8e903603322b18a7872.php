<?php $__env->startSection('judul'); ?>
Form Koleksi Buku
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
  <div class="alert alert-danger alert-dismissible" role="alert">
     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><em>
  <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</em>
</div>
<?php endif; ?>
<form id="frmKoleksi" class="form-horizontal" action="<?php echo e(url('koleksi/save')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" class="form-control" id="kd_koleksi" placeholder="kd_koleksi" name="kd_koleksi" value="<?php echo e($koleksi['kd_koleksi']); ?>">
    <div class="row">        
        <div class="fForm col-md-12">
            <div class="box">
                <!-- Bidodata buku -->
                <div class="box-header with-border">
                    <h3 class="box-title">Koleksi buku</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label for="kd_buku" class="col-sm-2 control-label">Buku</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="kd_buku" <?php echo e($koleksi['kd_buku']!="" ? 'disabled' : ""); ?> value="<?php echo e($koleksi['kd_buku']); ?>">
                                <option value="">- Pilih Buku -</option>
                                <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsBuku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($koleksi['kd_buku']==$rsBuku['kd_buku'] ? 'selected' : ""); ?> value="<?php echo e($rsBuku['kd_buku']); ?>"><?php echo e($rsBuku['judul']); ?></option>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                             
                            </select>
                        </div>
                    </div> 
                    <div class="form-group">
                        <label for="tgl_pengadaan" class="col-sm-2 control-label">Tanggal Pengadaan</label>
                        <div class="col-sm-10">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>        
                                <input id="datepicker" type="text" class="form-control" id="tanggal_pengadaan" placeholder="Tanggal Pengadaan" name="tanggal_pengadaan" value="<?php echo e($koleksi['tanggal_pengadaan']); ?>">
                            </div>
                        </div>                        
                    </div>
                    <div class="form-group">
                        <label for="akses" class="col-sm-2 control-label">Akses</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="akses" value="<?php echo e($koleksi['akses']); ?>">
                                <option value="">- Pilih Akses -</option>
                                <option <?php echo e($koleksi ['akses']=="Boleh Dipinjam" ? 'selected' : ''); ?> value="Boleh Dipinjam">Boleh Dipinjam</option>
                                <option <?php echo e($koleksi ['akses']=="Baca di Tempat" ? 'selected' : ''); ?>value="Baca di Tempat">Boleh Baca di Tempat</option>                        
                            </select>
                        </div>
                    </div> 
                    <div class="form-group">
                        <label for="rak" class="col-sm-2 control-label">Rak</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="kd_rak" value="<?php echo e($koleksi['kd_rak']); ?>">
                                <option value="">- Pilih Rak -</option>
                                <?php $__currentLoopData = $rak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsRak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($koleksi['kd_rak']==$rsRak['kd_rak'] ? 'selected' : ''); ?> value="<?php echo e($rsRak['kd_rak']); ?>"><?php echo e($rsRak['nama_rak']); ?></option>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                             
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="sumber" class="col-sm-2 control-label">Sumber Buku</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="sumber" placeholder="Sumber Buku" name="sumber" value="<?php echo e($koleksi['sumber']); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="status" class="col-sm-2 control-label">Status</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="status" value="<?php echo e($koleksi['status']); ?>">
                                <option value="">- Pilih Status -</option>
                                <option <?php echo e($koleksi['status']==0 ? 'selected' : ''); ?> value="0">Tersedia</option>
                                <option <?php echo e($koleksi['status']==1 ? 'selected' : ''); ?> value="1">Dipinjam</option>  
                                <option <?php echo e($koleksi['status']==2 ? 'selected' : ''); ?> value="2">Rusak</option>
                                <option <?php echo e($koleksi['status']==3 ? 'selected' : ''); ?> value="3">Hilang</option>
                            </select>
                        </div>
                    </div>
                    <?php if($koleksi['kd_koleksi']==""): ?>
                    <div class="form-group">
                        <label for="jumlah" class="col-sm-2 control-label">Jumlah Buku</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="jumlah" placeholder="Jumlah Buku" name="jumlah" value="">
                        </div>
                    </div>  
                    <?php endif; ?>   
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                    <button  type="submit" class="btn btn-primary pull-right">Save</button>
                </div>                   
            </div>
        </div>       
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>