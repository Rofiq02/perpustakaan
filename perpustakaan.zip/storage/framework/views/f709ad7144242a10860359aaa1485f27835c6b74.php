<?php $__env->startSection('judul'); ?>
Form Pengarang Buku
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
  <div class="alert alert-danger alert-dismissible" role="alert">
     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><em>
  <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</em>
</div>
<?php endif; ?>

<form id="frmPengarang" class="form-horizontal" action="<?php echo e(url('pengarang/save')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="fForm col-md-12">
            <div class="box">
                <!-- Bidodata pengarang -->
                <div class="box-header with-border">
                    <h3 class="box-title">Data pengarang</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label for="nama_pengarang" class="col-sm-2 control-label">Nama pengarang</label>
                        <div class="col-sm-10">
                            <input type="hidden" name="kd_pengarang" value="<?php echo e($pengarang['kd_pengarang']); ?>">
                            <input type="text" class="form-control" id="nama_pengarang" placeholder="Nama pengarang" name="nama_pengarang" value="<?php echo e($pengarang['nama_pengarang']); ?>">
                        </div>
                    </div>    
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary pull-right">SAVE</button>
                </div>                   
            </div>
        </div>       
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>