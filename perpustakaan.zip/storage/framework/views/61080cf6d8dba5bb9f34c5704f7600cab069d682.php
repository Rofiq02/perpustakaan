<?php $__env->startSection('judul'); ?>
    Form Pengembalian
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ac-transaksi'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box">
    <div class="box-body">
        <?php if($pinjam==""): ?>
            <form id="frmKembali" action="<?php echo e(url('trans/pengembalian')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="judul" class="col-sm-12 control-label" style="text-align:center">No Pinjam</label>
                    <div class="col-sm-4"></div>
                    <div class="col-sm-4">
                        <input type="text" class="form-control" id="no_pinjam" placeholder="No Pinjam" name="no_pinjam">
                    </div>
                    <div class="col-sm-4"></div>
                </div>
            </form>
        <?php else: ?>
        <form id="frmPinjam" action="<?php echo e(url('trans/pengembalian/save')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <!-- Input No Anggota -->
            <input type="hidden" name="no_pinjam" value="<?php echo e($pinjam[0]->no_pinjam); ?>">
           <div class="box-header">
                <h3 class="box-title">#<?php echo e($pinjam[0]->no_pinjam); ?></h3>
                <br/><br/>
                No Anggota :<strong><?php echo e($pinjam[0]->no_anggota); ?> </strong><br/>
                Nama : <?php echo e($pinjam[0]->nama); ?>

           </div>
           <div class="box-header">
                <h3 class="box-title">Detail Peminjaman</h3>
            </div> 
            <!-- Table List Buku yang Dipinjam -->
            <table class="table table-hover"  style="margin-top: 15px;">
                <tbody id="lsBuku">
                    <tr style="background:#ccc;">
                        <th width="15%">No Induk Buku</th>
                        <th>Judul</th>
                        <th width="5%">Telat</th>
                        <th width="5%">Denda</th>
                    </tr>
                    <?php $__currentLoopData = $pinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsPinjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th width="10%">
                        <?php echo e($rsPinjam->no_induk_buku); ?>

                        <input type="hidden" name="no_induk[]" value="<?php echo e($rsPinjam->no_induk_buku); ?>">
                        </th>
                        <th><?php echo e($rsPinjam->judul); ?></th>
                        <th width="8%">
                        <!-- Menhitung Selisih Hari -->
                        <?php                        
                            $start = new DateTime($rsPinjam->tgl_kembali);
                            $end = new DateTime();
                            $selisih = $end->diff($start);   
                            
                            $lamadenda = 0;
                            if($end>$start){
                                $lamadenda = $selisih->d;
                            }
                            echo $lamadenda;
                        ?>
                        </th>
                        <th width="8%">
                        <?php echo e($lamadenda * 2000); ?>

                        <input type="hidden" name="denda" value="<?php echo e($lamadenda * 2000); ?>">
                        </th>
                    </tr>       
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>             
                </tbody>
            </table>
            <!--- Footer Box -->
            <div class="box-footer">
                <button type="submit" class="btn btn-success btn-flat">SAVE</button>
                <a href="<?php echo e(url('trans/pengembalian')); ?>"><button type="button" class="btn btn-warning btn-flat">CANCEL</button></a>
            </div> 
        </form>                                 
        <?php endif; ?>
    </div>
</div>


            <!-- LAPORAN DATA PINJAM-->
            <div class="box">
        <div class="box-header">
        <table id="example1" class="table table-bordered table-hover">
            <thead>
                <tr>
                  <th>No Pinjam</th>
                  <th>Nama Anggota</th>
                  <th>Judul Buku</th>
                  <th>Tanggal Pinjam</th>
                  <th>Tanggal Kembali</th>
                  <th>Denda</th>
                  <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tampil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsTam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                  <td><?php echo e($rsTam->no_pinjam); ?></td>
                  <td><?php echo e($rsTam->nama); ?></td>
                  <td><?php echo e($rsTam->judul); ?></td>
                  <td><?php echo e($rsTam->tgl_pinjam); ?></td>
                  <td><?php echo e($rsTam->tgl_kembali); ?></td>
                  <td><?php echo e($rsTam->denda); ?></td>
                  <td><?php echo e(($rsTam->status==1 ? "Dipinjam" : "" )); ?></td>
            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>