<?php $__env->startSection('judul'); ?>
Data Rak Buku
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ac-rak'); ?>
active
<?php $__env->stopSection(); ?>

<style>
  .inputfile {
	width: 200px!important;
	height: 200px!important;
	opacity: 0;
	overflow: hidden;
	position: absolute;
	z-index: -1;
}

</style>
<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header">
            
            <form action="<?php echo e(url('/rak/import')); ?>" method="post" enctype="multipart/form-data">
            <a href="rak/add"><button type="button" class="btn bg-green btn-flat margin">Add New</button></a>
            <button class="btn btn-primary btn-sm">Upload Excel</button>
                <?php echo csrf_field(); ?>

                <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <div class="form-group">
                        <label for="">File (.xls, .xlsx)</label>
                        <input type="file" class="form-control" name="file">
                        <p class="text-danger"><?php echo e($errors->first('file')); ?></p>
                    </div>
                </form>
        <table id="example2" class="table table-bordered table-hover">
            <thead>
                <tr>
                  <th>#</th>
                  <th>Nama</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $rak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsRak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                  <td><?php echo e($rsRak['kd_rak']); ?></td>
                  <td><?php echo e($rsRak['nama_rak']); ?></td>
                  <td>
                        <a href="/rak/edit/<?php echo e($rsRak->kd_rak); ?>"><button type="button" class="btn bg-yellow btn-flat"><i class="fa fa-pencil"></i></button></a>
                        <a onclick="return confimation_hapus(this)" link="/rak/hapus/<?php echo e($rsRak->kd_rak); ?>"><button type="button" class="btn bg-red btn-flat"><i class="fa fa-trash"></i></button></a>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>