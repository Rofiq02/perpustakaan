<?php $__env->startSection('judul'); ?>
Form Rak Buku
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
  <div class="alert alert-danger alert-dismissible" role="alert">
     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><em>
  <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</em>
</div>
<?php endif; ?>

<form id="frmRak" class="form-horizontal" action="<?php echo e(url('rak/save')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="fForm col-md-12">
            <div class="box">
                <!-- Bidodata rak -->
                <div class="box-header with-border">
                    <h3 class="box-title">Data rak</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label for="nama_rak" class="col-sm-2 control-label">Nama rak</label>
                        <div class="col-sm-10">
                            <input type="hidden" name="kd_rak" value="<?php echo e($rak['kd_rak']); ?>">
                            <input type="text" class="form-control" id="nama_rak" placeholder="Nama rak" name="nama_rak" value="<?php echo e($rak['nama_rak']); ?>">
                        </div>
                    </div>    
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary pull-right">SAVE</button>
                </div>                   
            </div>
        </div>       
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>