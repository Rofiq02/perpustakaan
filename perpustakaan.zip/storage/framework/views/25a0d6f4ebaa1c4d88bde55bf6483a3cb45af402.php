<?php $__env->startSection('judul'); ?>
Data Anggota
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ac-anggota'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header">
            <a href="anggota/add"><button type="button" class="btn bg-green btn-flat margin">Add New</button></a>
        <table id="example1" class="table table-bordered table-hover">
            <thead>
                <tr>
                  <th>#</th>
                  <th>No Anggota</th>
                  <th>Nama</th>
                  <th>Lahir</th>
                  <th>Alamat</th>
                  <th>Email</th>
                  <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsAngg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                  <td><?php echo e($rsAngg['kd_anggota']); ?></td>
                  <td><?php echo e($rsAngg['no_anggota']); ?>

                  </td>
                  <td><?php echo e($rsAngg['nama']); ?></td>
                  <td><?php echo e($rsAngg['tempat'].",".$rsAngg['tgl_lahir']); ?></td>
                  <td><?php echo e($rsAngg['alamat'].",".$rsAngg['kota']); ?></td>
                  <td><?php echo e($rsAngg['email']); ?>

                  </td>
                  <td>
                        <a href="/anggota/edit/<?php echo e($rsAngg->kd_anggota); ?>"><button type="button" class="btn bg-yellow btn-flat"><i class="fa fa-pencil"></i></button></a>
                        <a onclick="return confimation_hapus(this)" link="/anggota/hapus/<?php echo e($rsAngg->kd_anggota); ?>"><button type="button" class="btn bg-red btn-flat"><i class="fa fa-trash"></i></button></a>
                        <a href="/anggota/print/<?php echo e($rsAngg->kd_anggota); ?>" target="blank"><button type="button" class="btn bg-green btn-flat"><i class="fa fa-print"></i></button></a>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>