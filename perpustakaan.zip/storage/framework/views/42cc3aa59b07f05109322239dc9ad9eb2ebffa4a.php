<style>
    table { width: 100%; }
    table td { text-align: center; }
</style>
<table>
<?php
    $i = 1;
    $count = count($buku);
?>

<?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsBuku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(($i%6)==1): ?>
<tr> 
<?php endif; ?>
    <td width="20%"><img src="data:image/png;base64,<?php echo e(base64_encode(QrCode::format('png')->size(150)->color(41,41,97)->backgroundColor(243,110,109)->generate($rsBuku->no_induk_buku))); ?>">
    <p><?php echo e($rsBuku->no_induk_buku); ?></p>
    </td>
<?php if(($i%6)==0 || $i==$count): ?>
</tr> 
<?php endif; ?>

<?php
$i++;
?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
