<style>
    table {
        position: relative; 
        border-collapse:collapse; 
        width: 100%;
    }

    table td {
        border:1px solid #000;
        padding: 5px;
    }

    h1,h2,p {
        margin: 0;
        text-align: center;
    }

    p {
        padding-bottom: 15px;
        margin-bottom: 15px;
        border-bottom: 8px double #000;
    }

    .title {
        background: #ccc;
    }

</style>

<h1>PERPUSTAKAAN UMUM</h1>
<h2>WEARNES EDUCATION CENTER MADIUN</h2>
<p> Jl Thamrin 35 A Madiun, Telp : (0351) 456789 , www.wearneslib.com, perpus@wearneslib.com</p>

<table>
    <tr class="title">
        <td width="15%" style=text-align:center;>NO PINJAM</td>
        <td width="15%" style=text-align:center;>ISBN</td>
        <td width="35%" style=text-align:center;>JUDUL</td>
        <td width="15%" style=text-align:center;>TANGGAL PINJAM</td>
        <td width="15%" style=text-align:center;>TANGGAL KEMBALI</td>
    </tr>
    <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsBuku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($rsBuku->no_pinjam); ?></td>
        <td><?php echo e($rsBuku->ISBN); ?></td>
        <td><?php echo e($rsBuku->judul); ?></td>
        <td><?php echo e($rsBuku->tgl_pinjam); ?></td>
        <td><?php echo e($rsBuku->tgl_kembali); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>