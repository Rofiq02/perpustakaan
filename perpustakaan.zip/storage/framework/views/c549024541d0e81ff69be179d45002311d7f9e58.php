<?php $__env->startSection('judul'); ?>
Data Kategori
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ac-kategori'); ?>
active
<?php $__env->stopSection(); ?>

<style>
  .inputfile {
	width: 200px!important;
	height: 200px!important;
	opacity: 0;
	overflow: hidden;
	position: absolute;
	z-index: -1;
}

</style>
<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header">
            <form action="<?php echo e(url('/kategori/import')); ?>" method="post" enctype="multipart/form-data">
            <a href="kategori/add"><button type="button" class="btn bg-green btn-flat margin"><i class="fa fa-plus"></i></button></a>
            <button class="btn btn-primary btn-sm">Upload Excel</button>
                <?php echo csrf_field(); ?>

                <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <div class="form-group">
                        <label for="">File (.xls, .xlsx)</label>
                        <input type="file" class="form-control" name="file">
                        <p class="text-danger"><?php echo e($errors->first('file')); ?></p>
                    </div>
            <!--MULAI -->
    <!-- TUTUP -->
        <table id="example2" class="table table-bordered table-hover">
            <thead>
                <tr>
                  <th>#</th>
                  <th>Nama</th>
                  <th>Singkatan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsKat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                  <td><?php echo e($rsKat['kd_kategori']); ?></td>
                  <td><?php echo e($rsKat['nama_kategori']); ?></td>
                  <td><?php echo e($rsKat['singkatan']); ?></td>
                  <td>
                        <a href="/kategori/edit/<?php echo e($rsKat->kd_kategori); ?>"><button type="button" class="btn bg-yellow btn-flat"><i class="fa fa-pencil"></i></button></a>
                        <a onclick="return confimation_hapus(this)" link="/kategori/hapus/<?php echo e($rsKat->kd_kategori); ?>"><button type="button" class="btn bg-red btn-flat"><i class="fa fa-trash"></i></button></a>
                  </td>
            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>

    <script>
        var inputs = document.querySelectorAll( '.inputfile' );
Array.prototype.forEach.call( inputs, function( input )
{
	var label	 = input.nextElementSibling,
		labelVal = label.innerHTML;

	input.addEventListener( 'change', function( e )
	{
		var fileName = '';
		if( this.files && this.files.length > 1 )
			fileName = ( this.getAttribute( 'data-multiple-caption' ) || '' ).replace( '{count}', this.files.length );
		else
			fileName = e.target.value.split( '\\' ).pop();

		if( fileName )
			label.querySelector( 'span' ).innerHTML = fileName;
		else
			label.innerHTML = labelVal;
	});
});
    </script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>