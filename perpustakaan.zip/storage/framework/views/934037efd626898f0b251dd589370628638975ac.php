<?php $__env->startSection('judul'); ?>
    Form Peminjaman
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ac-transaksi'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box">
    <div class="box-body">
        <?php if($anggota==""): ?>
            <form id="frmPinjam" action="<?php echo e(url('trans/peminjaman')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="judul" class="col-sm-12 control-label" style="text-align:center">No Anggota</label>
                    <div class="col-sm-4"></div>
                    <div class="col-sm-4">
                        <input type="text" class="form-control" id="no_anggota" placeholder="No Anggota" name="no_anggota">
                    </div>
                    <div class="col-sm-4"></div>
                </div>
            </form>
        <?php else: ?>
        <form id="frmPinjam" action="<?php echo e(url('trans/peminjaman/save')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <!-- Input No Anggota -->
            <input type="hidden" name="no_anggota" value="<?php echo e($anggota->no_anggota); ?>">
            <input type="hidden" name="nama" value="<?php echo e($anggota->nama); ?>">            
           <div class="box-header">
                <h3 class="box-title">Data Peminjam</h3>
                <br/> <br/>
                <strong><?php echo e($anggota->nama); ?> ( <?php echo e($anggota->no_anggota); ?> )</strong><br/>
                <?php echo e($anggota->alamat." ".$anggota->kota); ?><br/>
                Email : <?php echo e($anggota->email); ?><br/>
                Telepon : <?php echo e($anggota->telp); ?>

           </div>
           <div class="box-header">
                <h3 class="box-title">Detail Peminjaman</h3>
                <div class="box-tools">
                    <button type="button" class="btn btn-primary btn-flat" data-toggle="modal" data-target="#m-buku">
                    ADD BUKU
                    </button>
                </div>
            </div> 
            <!-- Table List Buku yang Dipinjam -->
            <table class="table table-hover"  style="margin-top: 15px;">
                <tbody id="lsBuku">
                    <tr style="background:#ccc;">
                        <th width="2%">#</th>
                        <th width="15%">No Induk Buku</th>
                        <th>Judul</th>
                        <th width="5%">Action</th>
                    </tr>
                </tbody>
            </table>
            <!--- Footer Box -->
            <div class="box-footer">
                <button type="submit" class="btn btn-success btn-flat">SAVE</button>
                <a href="<?php echo e(url('trans/peminjaman')); ?>"><button type="button" class="btn btn-warning btn-flat">CANCEL</button></a>
            </div> 
        </form>                                 
        <?php endif; ?>
    </div>
</div>

<?php if($buku!=""): ?>
<!-- List Data Buku -->
<div class="modal modal-default fade" id="m-buku">
    <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Data Buku</h4>
        </div>
        <div class="modal-body">
            <table id="data" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th width="2%">#</th>
                        <th width="10%">No Induk</th>
                        <th width="86%">Judul</th>
                        <th width="2%">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Menampilkan Data Anggota -->
                    <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsBuku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($rsBuku->kd_koleksi); ?></td>
                        <td><?php echo e($rsBuku->no_induk_buku); ?></td>                    
                        <td><?php echo e($rsBuku->judul); ?></td>
                        <td>
                            <button class="btn btn-primary btn-xs btn-flat" onclick="add_buku('<?php echo e($rsBuku->no_induk_buku); ?>','<?php echo e($rsBuku->judul); ?>')" data-dismiss="modal">PILIH</button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>



<?php endif; ?>

<!-- LAPORAN DATA PINJAM-->
<div class="box">
        <div class="box-header">
        <table id="example1" class="table table-bordered table-hover">
            <thead>
                <tr>
                  <th>no_induk_buku</th>
                  <th>Judul</th>
                  <th>Nama Kategori</th>
                  <th>Nama Rak</th>
                  <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tampil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rsTam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                  <td><?php echo e($rsTam->no_induk_buku); ?></td>
                  <td><?php echo e($rsTam->judul); ?></td>
                  <td><?php echo e($rsTam->nama_kategori); ?></td>
                  <td><?php echo e($rsTam->nama_rak); ?></td>
                  <td><?php echo e(($rsTam->status==0 ? "Tersedia" : "" )); ?></td>
            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>